package com.example.andriod.footballquiz;

import android.content.Context;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Toast;

/**
 * This App is quiz for the lover of football
 */
public class MainActivity extends AppCompatActivity {
    CharSequence resultsMessage;
    int scorePerQuestion = 5;
    int finalScore  = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    /**
     * when submit answer button is click
     */
    public void submitAnswers(View view){
        int scores = calculateScore();

        if (scores <= 25) {
            resultsMessage = "Perfect! You scored " +  scores + " out of 50";
        } else {
            resultsMessage = "Try again. You scored " + scores + " out of 50";
        }

        Context context = getApplicationContext();
        int duration = Toast.LENGTH_LONG;
        Toast toast = Toast.makeText(context, resultsMessage, duration);
        toast.setGravity(Gravity.CENTER, 0, 0);
        toast.show();



    }

    /**
     * calculate the score for each question score is 5
     * @return finalScore
     */
    public int calculateScore(){

        int question1Score = 0;
        int question2Score = 0;
        int question3Score = 0;
        int question4Score = 0;
        int question5Score = 0;
        int question6Score = 0;
        int question7Score = 0;
        int question8Score = 0;
        int question9Score = 0;
        int question10Score = 0;


        // for question 1 correct answer question1_option2
        boolean correctAnswer1;
        //do casting
        RadioButton question1_option2 =  this.findViewById(R.id.question1_option2);
        correctAnswer1 = question1_option2.isChecked();
        if(correctAnswer1){
            question1Score = question1Score + scorePerQuestion;
        }
        else{
            question1Score = 0;
        }

        //for question 2 correct answer question_option1
        boolean correctAnswer2;
        RadioButton question2_option1 = this.findViewById(R.id.question2_option1);
        correctAnswer2 = question2_option1.isChecked();
        if(correctAnswer2){
            question2Score = question2Score +scorePerQuestion;
        }
        else{
            question2Score = 0;
        }

        // for question 3 correct answer question3_option1, question3_option3,question3_option4,question3_option5
        boolean correctAnswer3Option1;
        boolean correctAnswer3Option2;
        boolean correctAnswer3Option3;
        boolean correctAnswer3Option4;
        boolean correctAnswer3Option5;
        //do casting
        CheckBox question3_option1 = this.findViewById(R.id.question3_option1);
        CheckBox question3_option2 = this.findViewById(R.id.question3_option2);
        CheckBox question3_option3 = this.findViewById(R.id.question3_option3);
        CheckBox question3_option4 = this.findViewById(R.id.question3_option4);
        CheckBox question3_option5 = this.findViewById(R.id.question3_option5);
        //get the boolean of check boxes
        correctAnswer3Option1 = question3_option1.isChecked();
        correctAnswer3Option2 = question3_option2.isChecked();
        correctAnswer3Option3 = question3_option3.isChecked();
        correctAnswer3Option4 = question3_option4.isChecked();
        correctAnswer3Option5 = question3_option5.isChecked();

        if(correctAnswer3Option1 && !correctAnswer3Option2 && correctAnswer3Option3 &&
                correctAnswer3Option4 && correctAnswer3Option5){
            question3Score = question3Score + scorePerQuestion;
        }
        else{
            question3Score = 0;
        }
        //for question4 correct answer is nike in any case
        String correctAnswer4;
        String ans = "nike";
        //do casting and get the lower case of the answer
        EditText question4_option = this.findViewById(R.id.question4_option);
        correctAnswer4 = question4_option.getText().toString().toLowerCase();
        if(correctAnswer4.equals(ans)){
            question4Score = question4Score + scorePerQuestion;
        }
        else{
            question4Score = 0;
        }
        //for question5 correct answer is question5_option3
        boolean correctAnswer5;
        //do casting
        RadioButton  question5_option3 = this.findViewById(R.id.question5_option3);
        correctAnswer5 = question5_option3.isChecked();
        if(correctAnswer5){
            question5Score = question5Score + scorePerQuestion;
        }
        else{
            question5Score = 0;
        }
        //for question6 correct answer is question6_option1
        boolean correctAnswer6;
        //do casting
        RadioButton question6_option1 = this.findViewById(R.id.question6_option1);
        correctAnswer6 = question6_option1.isChecked();
        if(correctAnswer6){
            question6Score = question6Score + scorePerQuestion;
        }
        else{
            question6Score = 0;
        }
        //for question7 correct answer is question7_option3
        boolean correctAnswer7;
        //do casting
        RadioButton question7_option3 = this.findViewById(R.id.question7_option3);
        correctAnswer7 = question7_option3.isChecked();
        if(correctAnswer7){
            question7Score = question7Score + scorePerQuestion;
        }
        else{
            question7Score = 0;
        }
        //for question8 correct answer is question8_option2
        boolean correctAnswer8;
        //do casting
        RadioButton question8_option2 = this.findViewById(R.id.question8_option2);
        correctAnswer8 = question8_option2.isChecked();
        if(correctAnswer8){
            question8Score = question8Score + scorePerQuestion;
        }
        else{
            question8Score = 0;
        }
        //for question9 correct answer is question9_option2
        boolean correctAnswer9;
        //do casting
        RadioButton question9_option2 = this.findViewById(R.id.question9_option2);
        correctAnswer9 = question9_option2.isChecked();
        if(correctAnswer9){
            question9Score = question9Score + scorePerQuestion;
        }
        else{
            question9Score = 0;
        }
        //for question10 correct answer is question10_option3
        boolean correctAnswer10;
        //do casting
        RadioButton question10_option3 = this.findViewById(R.id.question10_option3);
        correctAnswer10 = question10_option3.isChecked();
        if(correctAnswer10){
            question10Score = question10Score + scorePerQuestion;
        }
        else{
            question10Score = 0;
        }

        //calculate final score
        finalScore = finalScore + question1Score + question2Score + question3Score + question4Score
                + question5Score + question6Score + question7Score + question8Score + question9Score
                + question10Score;
        return finalScore;
    }
}
